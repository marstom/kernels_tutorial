# My very first kernel


## Useful resources
[Deadelus community](https://www.youtube.com/watch?v=MwPjvJ9ulSc&t=1s&ab_channel=DaedalusCommunity)